const express = require('express');
const app = express();
app.use(express.json());
const jwt = require('jsonwebtoken');
const SECRET_KEY = "feb8e351373cdad70c1ec8f514b49acb66592dfd6f0127f9f2cbd0219445d3d3553a035a50ff183ab56433d54adf7150c4f155ab0c1de9ecc84441cf405dc27e7f8b8db104131410510016ad68871eeb486221537ccdb4929f626284bb0dd3fb72d9c332f477dff55283a24a2705ca98dd352003b25d7aaa561e13331031c5a2e99c770b4fffedf8ec3223b5e704c5d7fd1c7bf2ccfc2a6664081d55cff37018b30f3a7ecafe06e3cd7d4af2887ad6a68cf54c429dc049e0429141a67f31a83f794862e8fe800ad26d82757360e0114843492e93c62341a8106312b209dd7d209878ad9fd924e4f8e02eb020f8ade18c6402a68b6569432807f1a1e84bf1a917";

exports.authMiddleware = app.use((req, res, next) => {
    const token = req.headers["authorization"]?.split(' ')[1];
    if (!token) return res.status(401).send("Token not found!"); 

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403); 
        req.user = user;
        next();
    });
})

exports.adminMiddleware = app.use((req, res, next) => {
    console.log(req.user)
    if(req.user.role == 'admin')
        next();
    else
        res.json("Error: User can not perform crud operations on specific functionality!");
})

// exports.noEndpointApi = app.use((req, res, next) => {
//     res.status(404).send("No such endpoint exists!");
// });

// exports.errMiddleware = app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).send("Something went wrong!");
// });

