const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();



const { registerUser, loginUser, getProfile, updateProfile, getUserWishlist, deleteUser, getAllUsers, getMoviesBasedOnUserActivities} = require('./modules/user/UserController');
const { createMovie, getMoviesByFilter, getTopMoviesByGenre, getTopMoviesOfTheMonth, getMovieById, updateMovie, deleteMovie, getMovies, getMostPopularMovies, getTrendingGenres } = require('./modules/movies/MovieController');
const { createPerson, getPersons, getPersonById, updatePerson, deletePerson, getPersonByName, getMostSearchedActors } = require('./modules/persons/PersonController');
const { createReview, updateReview, getAllReviewsForMovie, getTopRatedReviewsForMovie, getMostDiscussedReviewsForMovie, getReviewPieGraph, getReviewBarGraph, deleteReviewByAdmin } = require('./modules/reviews/ReviewController');
const { getMoviesBasedOnGenreUserRatingAndUserActivity, getSimilarTitlesMovies, getTrendingMovies, getTopRatedMovies } = require('./modules/recommendation/RecommendationController');
const { createNewsArticle, getAllNewsArticles, getNewsArticleById, updateNewsArticle, deleteNewsArticle } = require('./modules/newsArticlesIndustryUpdates/NewsArticlesAndIndustryUpdatesController');
const { createAward, getAllAwards, getAwardById, updateAward, deleteAward, displayAwardsForAMovie, displayAwardsForAActors } = require('./modules/boxofficeAndAwards/AwardController');
const { createBoxOffice, getAllBoxOfficeRecords, getBoxOfficeByMovie, updateBoxOffice, deleteBoxOffice } = require('./modules/boxofficeAndAwards/BoxOfficeController');
const CustomListController = require('./modules/customLists/CustomListContoller');
const { createPost, getAllPosts, addComment, getCommentsByPost, getAnyPosts, deleteAnyPost, updateAnyPost, updateComment, deleteComment } = require('./modules/communityPostsAndComments/CommunityPostsAndCommentsController');
const { getUpcomingMovies , addReminder, removeReminder, sendUpcomingReleaseNotifications, sendNewReleaseNotifications} = require('./modules/subscription/SubscriptionController');
const { authMiddleware, adminMiddleware, noEndpointApi, errMiddleware } = require('./middlewares/Middlewares');

const app = express();
app.use(express.json());

mongoose.connect("mongodb://localhost:27017", {}).then(() => {
    console.log("Connection built");
}).catch((e) => {
    console.log("Connection failed");
});

app.listen(3213, () => {
    console.log(`Server is running on port 3213`);
})



//APIS
//Apis that do not need token to be authenticated
app.post('/user/register', (req, res) => { return registerUser(req, res);});
app.post('/user/login' , (req, res) => {return loginUser(req, res);});

//Apis that do need authorization
app.get('/user/profile', authMiddleware, (req, res) => {return getProfile(req, res);});
app.put('/user/profile', authMiddleware,  (req, res) => {return updateProfile(req, res);});
app.get('/user/wishlist', authMiddleware, (req, res) => {return getUserWishlist(req, res);});
app.delete('/user/delete/:userId', authMiddleware, (req, res) => {return deleteUser(req, res)});
app.get('/user/getAll/:pageNo/:noOfEntries', authMiddleware, getAllUsers);
app.get('/user/getUserWishlist/:userId' , authMiddleware, (req, res) => {return getUserWishlist(req, res)});
app.get('/user/getMoviesBasedOnUserActivities/:userId' , authMiddleware, (req, res) => {return getMoviesBasedOnUserActivities(req, res)});

//person Apis
app.post('/persons', authMiddleware, (req, res) => {return createPerson(req, res);});
app.get('/getAllPersons/:pageNo/:pageSize', authMiddleware, (req, res) => getPersons(req, res));
app.get('/getPersonsById/:id', authMiddleware, (req, res) => {return getPersonById(req, res);});
app.get('/getPersonsByName/:name', authMiddleware, (req, res) => {return getPersonByName(req, res);});
app.put('/persons/:id', authMiddleware, (req, res) => {return updatePerson(req, res);});
app.delete('/persons/:id', authMiddleware, (req, res) => {return deletePerson(req, res);});
app.get('/getMostSearchedActors', authMiddleware, (req, res) => {return getMostSearchedActors(req, res);});

//movies Apis
app.post('/movies', authMiddleware, adminMiddleware, (req, res) => {return createMovie(req, res);});
app.get('/movies/:pageNo/:pageSize', authMiddleware, (req, res) => {return getMovies(req, res);});
app.get('/movies/getMoviesByFilter', authMiddleware, (req, res) => {return getMoviesByFilter(req, res);});
app.get('/movies/getTopMoviesByGenre/:pageNo/:pageSize', authMiddleware, (req, res) => {return getTopMoviesByGenre(req, res);});
app.get('/movies/getTopMoviesOfTheMonth/:pageNo/:pageSize', authMiddleware, (req, res) => {return getTopMoviesOfTheMonth(req, res);});
app.get('/movies/:id', authMiddleware, (req, res) => {return getMovieById(req, res);});
app.put('/movies/:id', authMiddleware, adminMiddleware, (req, res) => {return updateMovie(req, res);});
app.delete('/movies/:id', authMiddleware, adminMiddleware, (req, res) => {return deleteMovie(req, res);});
app.get('/movies/getPopular/:pageNo/:pageSize', authMiddleware, (req, res) => {return getMostPopularMovies(req, res);})
app.get('/movies/getTrendingGenres/:pageNo/:pageSize', authMiddleware, (req, res) => {return getTrendingGenres(req, res);})

//reviews Apis
app.post('/reviews', authMiddleware, (req, res) => {return createReview(req, res)});
app.put('/reviews/:reviewId', authMiddleware, (req, res) => {return updateReview(req, res)});
app.get('/reviews/getAllForMovie/:movie', authMiddleware, (req, res) => {return getAllReviewsForMovie(req, res)});
app.get('/reviews/getTopRatedReviewsForMovie/:movie', authMiddleware, (req, res) => {return getTopRatedReviewsForMovie(req, res)});
app.get('/reviews/getMostDiscussedReviews/', authMiddleware, (req, res) => {return getMostDiscussedReviewsForMovie(req, res)})
app.get('/reviews/getPieChart/:movieId', authMiddleware, (req, res) => {return getReviewPieGraph(req, res)});
app.get('/reviews/getBarChart/:movieId', authMiddleware, (req, res) => {return getReviewBarGraph(req, res)});
app.delete('/reviews/deleteReviewByAdmin/:reviewId', authMiddleware, adminMiddleware, (req, res) => {return deleteReviewByAdmin(req, res)});

//recommendation System
app.get('/movies/getMoviesBasedOnGenreUserRatingAndUserActivity/:userId', authMiddleware, (req, res) => {return getMoviesBasedOnGenreUserRatingAndUserActivity(req, res)});
app.get('/movies/getSimilarTitles/:movieId', authMiddleware, (req, res) => {return getSimilarTitlesMovies(req, res)});
app.get('/movies/getTrendingMovies/:userId', authMiddleware, (req, res) => {return getTrendingMovies(req, res)});
app.get('/movies/getTopRatedMovies/:userId', authMiddleware, (req, res) => {return getTopRatedMovies(req, res)});

//News, Articles, and Industry Updates
app.post('/newsArticles', authMiddleware, (req, res) => {return createNewsArticle(req, res)});
app.get('/getAllnewsArticles', authMiddleware, (req, res) => getAllNewsArticles(req, res));
app.get('/getSingleNewsArticles/:id', authMiddleware, (req, res) => getNewsArticleById(req, res));
app.put('/newsArticles/:id', authMiddleware, (req, res) => updateNewsArticle(req, res));
app.delete('/newsArticles/:id', authMiddleware, (req, res) => deleteNewsArticle(req, res));

// Award Routes
app.post('/awards', authMiddleware, (req, res) => {return createAward(req, res);});
app.get('/awards', authMiddleware, (req, res) => {return getAllAwards(req, res);});
app.get('/awards/:id', authMiddleware, (req, res) => {return getAwardById(req, res);});
app.put('/awards/:id', authMiddleware, (req, res) => {return updateAward(req, res);});
app.delete('/awards/:id', authMiddleware, (req, res) => {return deleteAward(req, res);});
app.get('/awards/getAwardsForMovie/:movieId', authMiddleware, (req, res) => {return displayAwardsForAMovie(req, res)});
app.get('/awards/getAwardsForActor/:personId', authMiddleware, (req, res) => {return displayAwardsForAActors(req, res)});

// Box Office Routes
app.post('/boxoffice', authMiddleware, (req, res) => {return createBoxOffice(req, res);});
app.get('/boxoffice', authMiddleware, (req, res) => {return getAllBoxOfficeRecords(req, res);});
app.get('/boxoffice/:movieId', authMiddleware, (req, res) => {return getBoxOfficeByMovie(req, res);});
app.put('/boxoffice/:movieId', authMiddleware, (req, res) => {return updateBoxOffice(req, res);});
app.delete('/boxoffice/:id', authMiddleware, (req, res) => {return deleteBoxOffice(req, res);});

// Custom and Saved List
app.post('/customList/create', authMiddleware, (req, res) => CustomListController.createCustomListTitle(req, res));
app.post('/watchlist/create', authMiddleware, (req, res) => CustomListController.createWatchList(req, res));
app.post('/savedlist/create', authMiddleware, (req, res) => CustomListController.createSavedList(req, res));
app.put('/customListOrWatchList/addMovie', authMiddleware, (req, res) => CustomListController.addMovieToCustomList(req, res));
app.put('/customList/updateTitle', authMiddleware, (req, res) => CustomListController.updateCustomListTitle(req, res));
app.put('/customListOrWatchList/deleteMovie', authMiddleware, (req, res) => CustomListController.deleteMovieFromCustomList(req, res));
app.put('/customListOrWatchList/clearMovies', authMiddleware, (req, res) => CustomListController.deleteAllMoviesFromCustomList(req, res));
app.delete('/customListSavedListOrWatchList/deleteList', authMiddleware, (req, res) => CustomListController.deleteCustomList(req, res));
app.get('/customList/user/:userId/customLists', authMiddleware, (req, res) => CustomListController.getUserCustomLists(req, res));
app.get('/customList/user/:userId/customList/:listId', authMiddleware, (req, res) => CustomListController.getUserCustomListById(req, res));
app.get('/savedList/user/:userId/savedLists', authMiddleware, (req, res) => CustomListController.getUserSavedLists(req, res));
app.get('/savedList/savedList/:listId', authMiddleware, (req, res) => CustomListController.getSavedListById(req, res));
app.get('/watchList/getWatchList/user/:userId', authMiddleware, (req, res) => CustomListController.getWatchList(req, res));

//Community Posts and Comments
app.post('/posts', authMiddleware, createPost);
app.get('/posts', authMiddleware, getAllPosts);
app.get('/posts/:id', authMiddleware, getAnyPosts);
app.delete('/posts/:id', authMiddleware, deleteAnyPost);
app.put('/posts/:id', authMiddleware,updateAnyPost)

app.post('/posts/:postId/comments', authMiddleware, addComment);
app.get('/posts/:postId/comments', authMiddleware, getCommentsByPost);
app.put('/posts/:postId/comments/:commentId', authMiddleware, updateComment);
app.delete('/posts/:postId/comments/:commentId', authMiddleware, deleteComment);

//Subscription
app.get('/upcomingMovies', authMiddleware, getUpcomingMovies); 
app.post('/addReminder', authMiddleware, addReminder);
app.delete('/removeReminder', authMiddleware, removeReminder);
app.post('/sendUpcomingReleaseNotifications', authMiddleware, sendUpcomingReleaseNotifications); 
app.post('/sendNewReleaseNotifications', authMiddleware, sendNewReleaseNotifications); 

// app.use(noEndpointApi);
// app.use(errMiddleware);