const mongoose = require('mongoose');

const SubscriptionSchema = new mongoose.Schema({
    userIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    movieId: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }
});

const Subscription = mongoose.model("Subscription", SubscriptionSchema);
module.exports = Subscription;
