const Movie = require("../movies/MovieModel");
const nodemailer = require('nodemailer');
const User = require("../user/UserModel");
const Subscription = require("./Subscription");

const transporter = nodemailer.createTransport({
    service:'gmail',
    auth:{
        user:'i222510@nu.edu.pk',
        pass:'Pakistan2510@'
    }
});

const sendEmail = async (to, subject, text) => {
    const mail = {
        from: 'i222510@nu.edu.pk',
        to,
        subject,
        text
    };

    try {
        await transporter.sendMail(mail);
        console.log(`Email sent to ${to}`);
    } catch (error) {
        console.error(`Failed to send email to ${to}: ${error}`);
    }
};



const getUpcomingMovies = async (req, res) => {
    try {
        const currentDate = new Date();
        const upcomingMovies = await Movie.find({ releaseDate: { $gt: currentDate } });
        res.status(200).json(upcomingMovies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const addReminder = async (req, res) => {
    try {
        const { userId, movieId } = req.body;

        let subscription = await Subscription.findOne({ movieId });

        if (!subscription) {
            subscription = new Subscription({ movieId, userIds: [userId] });
        } else if (!subscription.userIds.includes(userId)) {
            subscription.userIds.push(userId);
        }

        await subscription.save();
        res.status(200).json({ message: "Reminder set successfully." });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const removeReminder = async (req, res) => {
    try {
        const { userId, movieId } = req.body;

        const subscription = await Subscription.findOne({ movieId });
        if (subscription) {
            subscription.userIds = subscription.userIds.filter(id => id.toString() !== userId);
            await subscription.save();
        }

        res.status(200).json({ message: "Unsubscribed successfully." });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const sendUpcomingReleaseNotifications = async () => {
    const currentDate = new Date();
    const upcomingMovies = await Movie.find({ 
        releaseDate: { $gte: currentDate, $lte: new Date(currentDate.getTime() + 24 * 60 * 60 * 1000) } 
    });

    await Promise.all(upcomingMovies.map(async (movie) => {
        const subscription = await Subscription.findOne({ movieId: movie._id }).populate('userIds');
        if (subscription) {
            await Promise.all(subscription.userIds.map(async (user) => {
                const subject = `Upcoming Movie Release: ${movie.title}`;
                const text = `Hi ${user.name},\n\nDon't miss the upcoming release of ${movie.title} on ${movie.releaseDate.toDateString()}.\n\nEnjoy watching!\n\n`;
                await sendEmail(user.email, subject, text);
            }));
        }
    }));
};

const sendNewReleaseNotifications = async () => {
    const currentDate = new Date();
    const newMovies = await Movie.find({ releaseDate: { $lte: currentDate } });
    const users = await User.find();

    await Promise.all(users.map(async (user) => {
        const favoriteGenres = user.userPreferences.favoriteGenre;
        const matchingMovies = newMovies.filter(movie => movie.genre.some(genre => favoriteGenres.includes(genre)));

        if (matchingMovies.length > 0) {
            const subject = "New Movie Releases in Your Favorite Genres";
            const movieTitles = matchingMovies.map(movie => movie.title).join(', ');
            const text = `Hi ${user.name},\n\nCheck out these new releases in your favorite genres: ${movieTitles}.\n\nEnjoy watching!\n\nBest,\nMovieApp Team`;
            await sendEmail(user.email, subject, text);
        }
    }));
};


module.exports = {
    getUpcomingMovies,
    addReminder,
    removeReminder,
    sendUpcomingReleaseNotifications,
    sendNewReleaseNotifications
};

