const mongoose = require('mongoose');

const CommunityPostSchema = new mongoose.Schema({
    title: String,
    content: String,
    genre: [String],  // for categorizing discussions
    movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie' },  
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }],
    createdAt: { type: Date, default: Date.now },
    likes: { type: Number, default: 0 }
});

const CommunityPost = mongoose.model('CommunityPost', CommunityPostSchema);
module.exports = CommunityPost;
