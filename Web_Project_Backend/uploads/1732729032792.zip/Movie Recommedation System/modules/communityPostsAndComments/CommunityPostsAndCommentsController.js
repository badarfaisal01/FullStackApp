
const Comment = require("./Comment");
const CommunityPost = require("./CommunityPostModel");


const createPost = async (req, res) => {
    try {
        const { title, content, genre, movie, author } = req.body;
        const post = new CommunityPost({ title, content, genre, movie, author });
        await post.save();
        res.status(201).json(post);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get all community posts
const getAllPosts = async (req, res) => {
    try {
        const posts = await CommunityPost.find()
            // .populate('author')
            .populate('movie')
            .populate('comments');
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get any community posts
const getAnyPosts = async (req, res) => {
    try {
        
        const posts = await CommunityPost.findById(req.params.id)
            // .populate('author')
            .populate('movie');
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateAnyPost = async (req, res) => {
    try {
        const { title, content, genre, movie, author } = req.body;
        
        const posts = await CommunityPost.findById(req.params.id)
            // .populate('author')
            .populate('movie');

        if(!posts)
            res.status(500).json("Already Deleted or post not found");

        posts.title = title;
        posts.content = content;
        posts.genre = genre;
        posts.movie = movie;
        posts.author = author;

        await posts.save();
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteAnyPost = async (req, res) => {
    try {
        
        const posts = await CommunityPost.deleteOne({_id: req.params.id})
            // .populate('author')
            .populate('movie');
        console.log(posts)
            if(posts.deletedCount == 0)
                res.status(500).json("Already Deleted or post not found");
        res.status(200).json("Deleted");
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add a comment to a community post
const addComment = async (req, res) => {
    try {
        const { content, author, postId } = req.body;
        const comment = new Comment({ content, author, post: postId });
        await comment.save();

        // Add the comment to the post's comments array
        await CommunityPost.findByIdAndUpdate(postId, { $push: { comments: comment._id } });
        
        res.status(201).json(comment);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get comments for a specific post
const getCommentsByPost = async (req, res) => {
    try {
        const { postId } = req.params;
        const comments = await Comment.find({ post: postId })
        // .populate('author');
        res.status(200).json(comments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateComment = async (req, res) => {
    try {
        const { content } = req.body;  // Only allow updating content
        const { commentId } = req.params;

        const comment = await Comment.findById(commentId);

        if (!comment) {
            return res.status(404).json({ message: "Comment not found" });
        }

        // Update the content of the comment
        comment.content = content;
        await comment.save();

        res.status(200).json(comment);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteComment = async (req, res) => {
    try {
        const { postId, commentId } = req.params;

        // Find and delete the comment
        const comment = await Comment.findByIdAndDelete(commentId);
        if (!comment) {
            return res.status(404).json({ message: "Comment not found" });
        }

        // Remove the comment from the post's comments array
        await CommunityPost.findByIdAndUpdate(postId, { $pull: { comments: commentId } });

        res.status(200).json({ message: "Comment deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


module.exports = {
    createPost,
    getAllPosts,
    addComment,
    getCommentsByPost,
    getAnyPosts,
    deleteAnyPost,
    updateAnyPost,
    updateComment,
    deleteComment
};