// Person Controller
const Person = require('./PersonModel');

const createPerson = async (req, res) => {

    const person = new Person(req.body);
    const {filmography} = req.body;

    
    // Check if the person already exists
    const foundPerson = await Person.findOne({ name: person.name, birthDate: person.birthDate });
    if (foundPerson) {
        return res.status(400).json({ data: null, message: 'Person already exists with the same name and DOB' });
    }


    await person.save();
    
    res.status(201).json(person);
}

const getPersonById = async (req, res) => {
    const id = req.params.id;
    const person = await Person.findById(id).populate('filmography'); 

    if (person) {
        res.status(200).json(person);
    } else {
        res.status(404).json({ data: null, message: 'Person not found' });
    }
}

const getPersonByName = async (req, res) => {
    const name = req.params.name;
    const persons = await Person.find({ name: name }); 

    if (persons.length > 0) {
        res.status(200).json(persons);
    } else {
        res.status(404).json({ data: null, message: 'Person not found' });
    }
}

const getPersons = async (req, res) => {
    const pageNo = parseInt(req.query.pageNo) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;

    if (pageNo < 1 || pageSize < 1) {
        return res.status(400).json({ message: 'Invalid pagination parameters' });
    }

    const skip = (pageNo - 1) * pageSize;
    const persons = await Person.find()
        .skip(skip)
        .limit(pageSize)
        .populate('filmography');

    const totalPersons = await Person.countDocuments();

    res.status(200).json({
        data: persons
    });
};

const updatePerson = async (req, res) => {
    const updatedPerson = await Person.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedPerson) return res.status(404).json({ data: null, message: 'Person not found' });
    res.status(200).json(updatedPerson);
}

const deletePerson = async (req, res) => {
    try {
        const person = await Person.findByIdAndDelete(req.params.id);
        if (!person) return res.status(404).json({ data: null, message: 'Person not found' });
        res.status(200).json({ message: 'Person deleted successfully' });
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const getMostSearchedActors = async (req, res) => {
    try {
        const actorTrends = await User.aggregate([
            { $unwind: "$userPreferences.favoriteActors" },
            { $group: { _id: "$userPreferences.favoriteActors", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 5 }
        ]);

        const popularActors = await Person.find({ _id: { $in: actorTrends.map(a => a._id) } });
        res.status(200).json(popularActors);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


module.exports = {
    createPerson,
    getPersons,
    getPersonById,
    getPersonByName,
    updatePerson,
    deletePerson,
    getMostSearchedActors
};