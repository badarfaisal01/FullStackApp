const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('./UserModel');

const SECRET_KEY = "feb8e351373cdad70c1ec8f514b49acb66592dfd6f0127f9f2cbd0219445d3d3553a035a50ff183ab56433d54adf7150c4f155ab0c1de9ecc84441cf405dc27e7f8b8db104131410510016ad68871eeb486221537ccdb4929f626284bb0dd3fb72d9c332f477dff55283a24a2705ca98dd352003b25d7aaa561e13331031c5a2e99c770b4fffedf8ec3223b5e704c5d7fd1c7bf2ccfc2a6664081d55cff37018b30f3a7ecafe06e3cd7d4af2887ad6a68cf54c429dc049e0429141a67f31a83f794862e8fe800ad26d82757360e0114843492e93c62341a8106312b209dd7d209878ad9fd924e4f8e02eb020f8ade18c6402a68b6569432807f1a1e84bf1a917";



const registerUser = async (req, res) => {
    const user = new User(req.body);
    const { email, role } = req.body;
    if(!email || !role )
        res.status(400).send('Invalid Fields');
        
    if (!email.includes('@')) 
        return res.status(400).send('Invalid email format');

    const foundUser = await User.findOne({ email: email });
    if (foundUser) {
        res.status(400).send('User already exists');
    } else {
        const { password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);

        user.password = hashedPassword;

        await user.save();
        res.status(201).send(user);
    }
};

const loginUser = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email });
    if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ id: user._id, role:user.role }, SECRET_KEY, { expiresIn: '1h' });
        return res.send({
            "token": token,
            "id":user._id,
            "role":user.role
        });
    } else {
        return res.status(401).send('Invalid credentials');
    }
};

const getProfile = async (req, res) => 
{
    const userId = req.user.id;
    const user = await User.findById(userId).select("-password").populate('moviesWishlist').populate('userActivity');
    if (!user) {
            return res.status(404).send('User  not found');
    }
    res.json(user);
}

const getAllUsers = async (req, res) => {
    try {
        const pageNo = parseInt(req.params.pageNo, 10) || 1; 
        const noOfEntries = parseInt(req.params.noOfEntries, 10) || 10; 

        const skip = (pageNo - 1) * noOfEntries;

        const users = await User.find()
            .skip(skip)
            .limit(noOfEntries)
            .select("-password")
            .populate('moviesWishlist')
            .populate('userActivity');

        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateProfile = async (req, res) => {
    const userId = req.body._id; 
    const user = req.body; 
    console.log(userId)
    try {
        const updatedUser  = await User.findByIdAndUpdate(userId, user, {
            new: true
        }).select('-password');

        if (!updatedUser ) {
            return res.status(404).send('User not found');
        }

        res.send(updatedUser);
    } catch (error) {
        console.error(error);
        res.status(500).json('Server error');
    }
};

const deleteUser  = async (req, res) => {
    const userId = req.params.userId;

    // Check if userId is provided
    if (!userId) {
        return res.status(400).json({ message: "User  Id is null" });
    }

    try {
        // Attempt to delete the user
        const user = await User.findByIdAndDelete(userId);

        if (user) {
            return res.status(200).json({ message: "User  is deleted!" });
        } else {
            return res.status(404).json({ message: "User  not found or not deleted!" });
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
};

const getUserWishlist = async (req, res) => {

    const movies = await User.findById(req.params.userId) 
        .populate('moviesWishlist')
        .select('moviesWishlist');
    
    if(movies)
        res.status(200).json(movies);
    return res.status(404).json({ message: "No movies found" });
}

const getMoviesBasedOnUserActivities = async(req, res) => {
    
    const movies = await User.findById(req.params.userId) 
        .populate('userActivity')
        .select('userActivity');
    
    if(movies)
        res.status(200).json(movies);
    return res.status(404).json({ message: "No movies found" });
}

module.exports = {
    registerUser,
    loginUser,
    getProfile,
    updateProfile,
    getUserWishlist,
    deleteUser,
    getAllUsers,
    getMoviesBasedOnUserActivities
};
