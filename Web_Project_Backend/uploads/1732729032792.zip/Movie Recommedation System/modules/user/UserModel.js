const mongoose = require('mongoose');

const UserPreferencesSchema = new mongoose.Schema({
    favoriteGenre: [String],
    favoriteActors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Person' }]
});

const UserSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    role:String,
    moviesWishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }],
    userPreferences: UserPreferencesSchema,
    refreshToken: String,
    userActivity: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }], 
});

const User = mongoose.model("User ", UserSchema);

module.exports = User;

