const Movie = require("../movies/MovieModel");
const Person = require("../persons/PersonModel");
const Review = require("../reviews/ReviewModel");
const { getMoviesBasedOnUserActivities } = require("../user/UserController");
const User = require("../user/UserModel");

exports.getMoviesBasedOnGenreUserRatingAndUserActivity = async (req, res) => {
    try {//Prefernces
        const userId = req.params.userId;

        const user = await User.findById(userId)
            .populate('userActivity');
        if (!user || !user.userPreferences) {
            return res.status(404).json({ message: 'User  or preferences not found' });
        }

        const moviesBasedOnUserRatings = await Review.find({ user: userId })
            .populate('movie');


        const favGenreMovies = await Movie.find({
            genre: { $in: user.userPreferences.favoriteGenre }
        });

        
        const movieIds = new Set([
            ...moviesBasedOnUserRatings.map(review => review.movie._id),
        ]);

        // Add favorite genre movie IDs to the Set
        favGenreMovies.forEach(mov => {
            movieIds.add(mov._id); 
        });

        // Convert Set of unique IDs back to an array
        const uniqueMovieIds = Array.from(movieIds);

        const uniqueMovies = await Movie.find({ _id: { $in: uniqueMovieIds } });

        console.log(uniqueMovies); 

        res.status(200).send(uniqueMovies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getSimilarTitlesMovies = async (req, res) => {
    try {
        const movieId = req.params.movieId;

        const movie = await Movie.findById(movieId);
        if (!movie) {
            return res.status(404).json({ message: 'Movie not found' });
        }

        const moviesWithSimilarGenre = await Movie.find({ genre: movie.genre });
        const moviesWithSimilarDirector = await Movie.find({ director: movie.director });

        // const moviesBasedOnUserActivity = await getMoviesBasedOnUserActivities(req, res);

        const movieIds = new Set([
            ...moviesWithSimilarGenre.map(mov => mov._id),
            ...moviesWithSimilarDirector.map(mov => mov._id)
            // ...moviesBasedOnUserActivity.map(mov => mov._id)
        ]);

        const uniqueMovieIds = Array.from(movieIds);

        const uniqueMovies = await Movie.find({ _id: { $in: uniqueMovieIds } });

        const returnedMovies = uniqueMovies.filter(mov => mov._id.toString() !== movieId);

        res.status(200).json(returnedMovies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getTrendingMovies = async (req, res) => {
    const userId = req.params.userId;
    const moviesBasedOnUserRatings = await Review.find({ user: userId })
        .sort({ rating: -1 })
        .populate('movie')
        .select('movie')
        .limit(10);

    // const moviesbasedOnUserActivity = await User.find({ user: userId })
    //     .sort({ rating: -1 })
    //     .populate('userActivity')
    //     .select('userActivity')
    //     .limit(10);

        const movies = new Set([
            ...moviesBasedOnUserRatings
            // ...moviesBasedOnUserActivity
        ]);
        
        const uniqueMoviesArray = Array.from(movies);
        
        res.status(200).json(uniqueMoviesArray);
}

exports.getTopRatedMovies = async (req, res) => {
    const userId = req.body.userId;
    const moviesBasedOnUserRatings = await Review.find({ user: userId })
        .populate('movie')
        .select('movie')
        .sort({ popularity: -1 })
        .limit(10);

    // const moviesbasedOnUserActivity = await User.find({ user: userId })
    //     .populate('userActivity')
    //     .select('userActivity')
    //     .sort({ popularity: -1 })
    //     .limit(10);

    const movies = new Set([...moviesBasedOnUserRatings
        // , ...moviesbasedOnUserActivity
    ]);

    const uniqueMoviesArray = Array.from(movies);
        
     res.status(200).json(uniqueMoviesArray);
}

