const CustomList = require("./CustomListModel");

exports.createCustomListTitle = async (req, res) => {
    const { userId, title, type } = req.body;

    try {
        let customList = await CustomList.findOne({ title, userId });

        if (!customList) {
            customList = new CustomList({ userId, title, type, movies: [] });
            await customList.save();
            return res.status(200).json({ message: 'Custom list created successfully', customList });
        } else {
            return res.status(400).json({ message: 'List with this title already exists for the user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error creating custom list', error });
    }
};

exports.createWatchList = async (req, res) => {
    const { userId, title, type } = req.body;

    try {
        let customList = await CustomList.findOne({ title, userId });

        if (!customList) {
            customList = new CustomList({ userId, title, type, movies: [] });
            await customList.save();
            return res.status(200).json({ message: 'watch list created successfully', customList });
        } else {
            return res.status(400).json({ message: 'List with this title already exists for the user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error creating watch list', error });
    }
};

exports.createSavedList = async (req, res) => {
    const { userId, title, movies, type } = req.body;

    try {
        let savedList = await CustomList.findOne({ title, userId });

        if (!savedList) {
            savedList = new CustomList({ userId, title, type, movies: movies });
            await savedList.save();
            return res.status(200).json({ message: 'Saved List created successfully', savedList });
        } else {
            return res.status(400).json({ message: 'List with this title already exists for the user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error creating custom list', error });
    }
}

// Update a custom list (e.g., add a movie to the list)
exports.addMovieToCustomList = async (req, res) => {
    const { listId, movieId } = req.body;

    try {
        const customList = await CustomList.findById(listId);
        
        if (customList) {
            // if(customList.type = "savedList")
            //     return res.status(404).json({ message: 'Can not add movies to saved List' });
            customList.movies.push(movieId);
            await customList.save();
            return res.status(200).json({ message: 'Movie added to custom list', customList });
        } else {
            return res.status(404).json({ message: 'Custom list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error adding movie to custom list', error });
    }
};

// Update the title of a custom list
exports.updateCustomListTitle = async (req, res) => {
    const { listId, newTitle } = req.body;

    try {
        const customList = await CustomList.findById(listId);

        if (customList) {
            // if(customList.title == 'WatchList' || customList.title == 'savedList') 
            //     return res.status(400).json({ message: 'User can not update watchlist/ savedlist title' });
            customList.title = newTitle;
            await customList.save();
            return res.status(200).json({ message: 'Custom list title updated successfully', customList });
        } else {
            return res.status(404).json({ message: 'Custom list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error updating custom list title', error });
    }
};

// Delete a specific movie ID from a custom list
exports.deleteMovieFromCustomList = async (req, res) => {
    const { listId, movieId } = req.body;

    try {
        const customList = await CustomList.findById(listId);

        if (customList) {
            // if(customList.type == "savedList")
            //     return res.status(404).json({ message: 'Can not delete movies to saved List' });
            customList.movies = customList.movies.filter(id => id.toString() !== movieId);
            await customList.save();
            return res.status(200).json({ message: 'Movie removed from custom list', customList });
        } else {
            return res.status(404).json({ message: 'Custom list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error removing movie from custom list', error });
    }
};

// Delete all movies from a custom list
exports.deleteAllMoviesFromCustomList = async (req, res) => {
    const { listId } = req.body;

    try {
        const customList = await CustomList.findById(listId);

        if (customList) {
            if(customList.type == "savedList")
                return res.status(404).json({ message: 'Can not delete movies to saved List' });
            customList.movies = [];
            await customList.save();
            return res.status(200).json({ message: 'All movies removed from custom list', customList });
        } else {
            return res.status(404).json({ message: 'Custom list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error clearing movies from custom list', error });
    }
};

// Delete a custom list by ID
exports.deleteCustomList = async (req, res) => {
    const { listId } = req.body;

    try {
        const customList = await CustomList.findByIdAndDelete(listId);

        if (customList) {
            return res.status(200).json({ message: 'Custom list deleted successfully' });
        } else {
            return res.status(404).json({ message: 'Custom list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error deleting custom list', error });
    }
};

// Get all custom lists of a user
exports.getWatchList = async (req, res) => {
    const { userId } = req.params;

    try {
        const customList = await CustomList.findOne({  userId, type: 'watchlist' });
        if (customList) {
            res.status(200).json({ message: 'watchlist retrieved successfully', customList });
        } else {
            res.status(404).json({ message: 'watchlist not found for this user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving watchlist', error });
    }
}

exports.getUserCustomLists = async (req, res) => {
    const { userId } = req.params;

    try {
        const customLists = await CustomList.find({ userId, type: 'customList' });
        if (customLists.length > 0) {
            res.status(200).json({ message: 'User custom lists retrieved successfully', customLists });
        } else {
            res.status(404).json({ message: 'No custom lists found for this user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving user custom lists', error });
    }
};

// Get a specific custom list by ID for a user
exports.getUserCustomListById = async (req, res) => {
    const { userId, listId } = req.params;

    try {
        const customList = await CustomList.findOne({ _id: listId, userId, type: 'customList' });
        if (customList) {
            res.status(200).json({ message: 'Custom list retrieved successfully', customList });
        } else {
            res.status(404).json({ message: 'Custom list not found for this user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving custom list', error });
    }
};

// Get all saved lists for a user
exports.getUserSavedLists = async (req, res) => {
    const { userId } = req.params;

    try {
        const savedLists = await CustomList.find({ userId, type: 'savedList' });
        if (savedLists.length > 0) {
            res.status(200).json({ message: 'User saved lists retrieved successfully', savedLists });
        } else {
            res.status(404).json({ message: 'No saved lists found for this user' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving saved lists', error });
    }
};

// Get a specific saved list by ID
exports.getSavedListById = async (req, res) => {
    const { listId } = req.params;

    try {
        const savedList = await CustomList.findOne({ _id: listId, type: 'savedList' });
        if (savedList) {
            res.status(200).json({ message: 'Saved list retrieved successfully', savedList });
        } else {
            res.status(404).json({ message: 'Saved list not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving saved list', error });
    }
};
