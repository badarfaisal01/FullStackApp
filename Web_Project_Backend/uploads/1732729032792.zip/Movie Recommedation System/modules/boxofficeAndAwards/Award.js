// models/Award.js

const mongoose = require('mongoose');

const AwardSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    person: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Person'
    },
    movie: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Movie'
    },
    type: {
        type: String,
    }
});

module.exports = mongoose.model('Award', AwardSchema);
