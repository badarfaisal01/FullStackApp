// controllers/AwardController.js

const Award = require("./Award");

// Create Award entry
exports.createAward = async (req, res) => {
    try {
        const { title, year, person, movie, type } = req.body;
        const award = new Award({ title, year, person, movie, type });

        await award.save();
        res.status(201).json({ message: 'Award created successfully', award });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get all Awards
exports.getAllAwards = async (req, res) => {
    try {
        const awards = await Award.find()
            .populate('person', 'name')
            .populate('movie', 'title')
            .sort({ year: -1 });
        res.json(awards);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get Award by ID
exports.getAwardById = async (req, res) => {
    try {
        const { id } = req.params;
        const award = await Award.findById(id)
            .populate('person', 'name')
            .populate('movie', 'title');

        if (!award) {
            return res.status(404).json({ message: 'Award not found' });
        }

        res.json(award);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Update Award by ID
exports.updateAward = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, year, person, movie, type } = req.body;

        const award = await Award.findByIdAndUpdate(
            id,
            { title, year, person, movie, type },
            { new: true, runValidators: true }
        );

        if (!award) {
            return res.status(404).json({ message: 'Award not found' });
        }

        res.json({ message: 'Award updated successfully', award });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete Award by ID
exports.deleteAward = async (req, res) => {
    try {
        const { id } = req.params;
        const award = await Award.findByIdAndDelete(id);

        if (!award) {
            return res.status(404).json({ message: 'Award not found' });
        }

        res.json({ message: 'Award deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.displayAwardsForAMovie = async (req, res) => {
    const movieId = req.params.movieId;
    let type = 'Movie'
    const awards = await Award.find({movie:movieId, type:type});


    console.log(awards);
    if(awards)
        res.status(200).json(awards);
    else
        res.status(400).send("No award found");
}

exports.displayAwardsForAActors = async (req, res) => {
    const personId = req.params.personId;

    let type = 'Actor';
    const awards = await Award.find({person:personId, type:type});

    if(awards)
        res.status(200).json(awards);
    else
        res.status(400).send("No award found");
}