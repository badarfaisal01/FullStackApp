const BoxOffice = require("./BoxOffice");


// Create Box Office entry
exports.createBoxOffice = async (req, res) => {
    try {
        const { movie, openingWeekendEarnings, totalEarnings, internationalRevenue } = req.body;
        const boxOffice = new BoxOffice({ movie, openingWeekendEarnings, totalEarnings, internationalRevenue });
        
        await boxOffice.save();
        res.status(201).json({ message: 'Box Office record created successfully', boxOffice });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get all Box Office entries
exports.getAllBoxOfficeRecords = async (req, res) => {
    try {
        const boxOffices = await BoxOffice.find().populate('movie', 'title');
        res.json(boxOffices);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get Box Office entry by Movie ID
exports.getBoxOfficeByMovie = async (req, res) => {
    try {
        const { movieId } = req.params;
        const boxOffice = await BoxOffice.findOne({ movie: movieId }).populate('movie', 'title');
        
        if (!boxOffice) {
            return res.status(404).json({ message: 'Box Office information not found' });
        }
        
        res.json(boxOffice);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Update Box Office entry by Movie ID
exports.updateBoxOffice = async (req, res) => {
    try {
        const { movieId } = req.params;
        const { openingWeekendEarnings, totalEarnings, internationalRevenue } = req.body;

        const boxOffice = await BoxOffice.findOneAndUpdate(
            { movie: movieId },
            { openingWeekendEarnings, totalEarnings, internationalRevenue },
            { new: true, runValidators: true }
        );

        if (!boxOffice) {
            return res.status(404).json({ message: 'Box Office information not found' });
        }

        res.json({ message: 'Box Office information updated successfully', boxOffice });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete Box Office entry by Movie ID
exports.deleteBoxOffice = async (req, res) => {
    try {
        const { movieId } = req.params;
        const boxOffice = await BoxOffice.findOneAndDelete({ movie: movieId });

        if (!boxOffice) {
            return res.status(404).json({ message: 'Box Office information not found' });
        }

        res.json({ message: 'Box Office information deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
