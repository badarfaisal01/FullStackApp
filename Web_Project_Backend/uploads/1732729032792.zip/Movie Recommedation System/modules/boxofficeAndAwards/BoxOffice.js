// models/BoxOffice.js

const mongoose = require('mongoose');

const BoxOfficeSchema = new mongoose.Schema({
    movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
    openingWeekendEarnings: { type: Number, required: true },
    totalEarnings: { type: Number, required: true },
    internationalRevenue: { type: Number, required: true }
});

module.exports = mongoose.model('BoxOffice', BoxOfficeSchema);
