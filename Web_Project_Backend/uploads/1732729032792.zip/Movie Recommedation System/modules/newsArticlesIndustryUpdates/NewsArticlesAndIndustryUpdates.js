const mongoose = require('mongoose');

const NewsArticleSchema = new mongoose.Schema({
    title: String,
    body: {
        type: String,
        required: true
    },
    images: [{
        type: String 
    }],
    type: {
        type:Number//1 for News, 2 for articles
    },
    persons:{
        type: mongoose.Schema.Types.ObjectId, ref:'Person'
    },
    movies:{
        type:mongoose.Schema.Types.ObjectId, ref:'Movie'
    }
});

module.exports = mongoose.model('NewsArticle', NewsArticleSchema);
