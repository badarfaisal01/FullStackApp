const NewsArticlesAndIndustryUpdates = require("./NewsArticlesAndIndustryUpdates");


exports.createNewsArticle = async (req, res) => {
    try {
        const { title, body, images, type, persons, movies } = req.body;

        const newsArticle = new NewsArticlesAndIndustryUpdates({
            title,
            body,
            images,
            type,
            persons,
            movies
        });

        await newsArticle.save();
        res.status(201).json({ message: 'News article created successfully', newsArticle });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAllNewsArticles = async (req, res) => {
    try {
        const newsArticles = await NewsArticlesAndIndustryUpdates.find()
            .populate('persons', 'name') 
            .populate('movies', 'title'); 
        res.json(newsArticles);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getNewsArticleById = async (req, res) => {
    try {
        const { id } = req.params;
        const newsArticle = await NewsArticlesAndIndustryUpdates.findById(id)
            .populate('persons', 'name')
            .populate('movies', 'title');

        if (!newsArticle) {
            return res.status(404).json({ message: 'News article not found' });
        }

        res.json(newsArticle);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateNewsArticle = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, body, images, type, persons, movies } = req.body;

        const updatedNewsArticle = await NewsArticlesAndIndustryUpdates.findByIdAndUpdate(
            id,
            { title, body, images, type, persons, movies },
            { new: true, runValidators: true }
        );

        if (!updatedNewsArticle) {
            return res.status(404).json({ message: 'News article not found' });
        }

        res.json({ message: 'News article updated successfully', updatedNewsArticle });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete a News/Article/Industry Update by ID
exports.deleteNewsArticle = async (req, res) => {
    try {
        const { id } = req.params;

        const deletedNewsArticle = await NewsArticlesAndIndustryUpdates.findByIdAndDelete(id);

        if (!deletedNewsArticle) {
            return res.status(404).json({ message: 'News article not found' });
        }

        res.json({ message: 'News article deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

