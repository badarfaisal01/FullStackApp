const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
    title: String,
    genre: [String],
    director: { type: mongoose.Schema.Types.ObjectId, ref: 'Person' }, 
    cast: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Person' }],  
    crew: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Person' }],  
    releaseDate: Date,
    runtime: Number,
    popularity:Number,
    synopsis: String,
    averageRating: Number,
    movieCoverPhoto: String,
    trivia: [String],
    goofs: [String],
    soundtrackInfo: [String],
    ageRating: String,
    parentalGuidance: String,
    countryOfOrigin:String,
    Language: String,
    keywords:[String],
    boxOffice:Number
});

const Movie = mongoose.model('Movie', MovieSchema);
module.exports = Movie;
