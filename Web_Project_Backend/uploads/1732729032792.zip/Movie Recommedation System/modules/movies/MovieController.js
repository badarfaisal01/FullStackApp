const Person = require("../persons/PersonModel");
const Review = require("../reviews/ReviewModel");
const Movie = require("./MovieModel");

//for creating movie, must update person information regarding movies
const createMovie = async (req, res) => {
    try {
        const movie = new Movie(req.body);
        // const persons = movie.
        await movie.save();

        res.status(201).json(movie);
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const getMovies = async (req, res) => {
    const pageNo = parseInt(req.params.pageNo);
    const pageSize = parseInt(req.params.pageSize);

    if (pageNo < 1 || pageSize < 1) {
        return res.status(400).json({ message: 'Invalid pagination parameters' });
    }

    const skip = (pageNo - 1) * pageSize;



    try {
        const movies = await Movie.find()
            .skip(skip)
            .limit(pageSize)
            .populate('director')
            .populate('cast')
            .populate('crew');



        res.status(200).json({

            movies
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getMoviesByFilter = async (req, res) => {
    try {
        const {
            title,
            genre,
            director,
            cast,
            minRating,
            maxRating,
            minPopularity,
            maxPopularity,
            releaseYear,
            releaseDecade,
            countryOfOrigin,
            language,
            keywords
        } = req.body;

        const movieSet = new Set();

        // Helper function to add movies to the set
        const addMoviesToSet = (movies) => {
            movies.forEach(movie => movieSet.add(movie._id.toString()));
        };

        // Fetch movies by title
        if (title) {
            const movies = await Movie.find({ title: title });
            addMoviesToSet(movies);
        }

        if (genre) {
            const movies = await Movie.find({ genre: { $in: genre } });
            addMoviesToSet(movies);
        }

        if (director) {
            const movies = await Movie.find({ director });
            addMoviesToSet(movies);
        }

        if (cast) {
            const movies = await Movie.find({ cast: { $in: cast } });
            addMoviesToSet(movies);
        }

        // Filter by exact rating
        if (minRating) {
            const movies = await Movie.find({ averageRating: { $gt: minRating } });
            addMoviesToSet(movies);
        }
        if (maxRating) {
            const movies = await Movie.find({ averageRating: { $lt: maxRating } });
            addMoviesToSet(movies);
        }

        // Filter by exact popularity
        if (maxPopularity || minPopularity) {
            const movies = await Movie.find({ popularity: { $lt: maxPopularity, $gt: minPopularity } });
            addMoviesToSet(movies);
        }


        // Filter by release year
        if (releaseYear) {
            const movies = await Movie.find({
                releaseDate: {
                    $gte: new Date(`${releaseYear}-01-01`),
                    $lte: new Date(`${releaseYear}-12-31`)
                }
            });
            addMoviesToSet(movies);
        }

        // Filter by release decade
        if (releaseDecade) {
            const startYear = parseInt(releaseDecade, 10);
            const endYear = startYear + 9;

            const movies = await Movie.find({
                releaseDate: {
                    $gte: new Date(`${startYear}-01-01`),
                    $lte: new Date(`${endYear}-12-31`)
                }
            });
            addMoviesToSet(movies);
        }

        // Filter by country of origin
        if (countryOfOrigin) {
            const movies = await Movie.find({ countryOfOrigin });
            addMoviesToSet(movies);
        }

        // Filter by language
        if (language) {
            const movies = await Movie.find({ Language: language });
            addMoviesToSet(movies);
        }

        // Filter by keywords in synopsis
        if (keywords) {
            const movies = await Movie.find({ keywords: { $in: keywords } });
            addMoviesToSet(movies);
        }

        const movieIds = Array.from(movieSet);
        const uniqueMovies = await Movie.find({ _id: { $in: movieIds } })
            .populate('director')
            .populate('cast')
            .populate('crew');

        res.status(200).json(uniqueMovies);
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const getTopMoviesByGenre = async (req, res) => {

    const pageNo = parseInt(req.params.pageNo);
    const pageSize = parseInt(req.params.pageSize);

    if (pageNo < 1 || pageSize < 1) {
        return res.status(400).json({ message: 'Invalid pagination parameters' });
    }

    const skip = (pageNo - 1) * pageSize;

    const { genre } = req.body;

    if (!genre) {
        return res.status(400).json({ message: 'Genre is required for this query' });
    }
    const movies = await Movie.find({ genre })
        .skip(skip)
        .sort({ averageRating: -1 })
        .limit(10)
        .populate('director')
        .populate('cast')
        .populate('crew');

    res.status(200).json(movies);
}

const getTopMoviesOfTheMonth = async (req, res) => {
    try {

        const pageNo = parseInt(req.params.pageNo);
        const pageSize = parseInt(req.params.pageSize);

        if (pageNo < 1 || pageSize < 1) {
            return res.status(400).json({ message: 'Invalid pagination parameters' });
        }

        const skip = (pageNo - 1) * pageSize;

        const movies = await Movie.find({
            releaseDate: {
                $lt: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1),
                $gt: new Date(new Date().getFullYear(), new Date().getMonth(), 1)
            }
        })
            .skip(skip)
            .sort({ averageRating: -1, popularity: -1 })
            .limit(10)
            .populate('director')
            .populate('cast')
            .populate('crew');

        res.status(200).json(movies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
const getMostPopularMovies = async (req, res) => {
    try {

        const pageNo = parseInt(req.params.pageNo);
        const pageSize = parseInt(req.params.pageSize);

        if (pageNo < 1) {
            return res.status(400).json({ message: 'Invalid pagination parameters' });
        }

        const skip = (pageNo - 1) * pageSize;

        const popularMovies = await Movie.find()
            .skip(skip)
            .sort({ popularity: -1 });

        res.status(200).json(popularMovies);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getMovieById = async (req, res) => {
    try {
        const pageNo = parseInt(req.params.pageNo);
        const pageSize = parseInt(req.params.pageSize);

        if (pageNo < 1 || pageSize < 1) {
            return res.status(400).json({ message: 'Invalid pagination parameters' });
        }

        const skip = (pageNo - 1) * pageSize;

        const movie = await Movie.findById(req.params.id)
            .skip(skip)
            .populate('director')
            .populate('cast')
            .populate('crew');
        if (!movie) {
            return res.status(404).json({ data: null, message: 'Movie not found' });
        }
        res.status(200).json(movie);
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const updateMovie = async (req, res) => {
    try {
        const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!movie) {
            return res.status(404).json({ data: null, message: 'Movie not found' });
        }
        res.status(200).json(movie);
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const deleteMovie = async (req, res) => {
    try {
        const movie = await Movie.findByIdAndDelete(req.params.id);
        if (!movie) {
            return res.status(404).json({ data: null, message: 'Movie not found' });
        }

        await deleteRelatedMovies(movie);

        res.status(200).json({ message: 'Movie deleted successfully' });
    } catch (error) {
        res.status(500).json({ data: null, message: error.message });
    }
};

const deleteRelatedMovies = async (movie) => {
    await User.updateMany({
        $pull: { userActivity: movie._id, moviesWishlist: movie._id }
    });

    await Person.updateMany({
        $pull: { filmography: movie._id }
    });

    const reviewsToDel = await Review.find({ movie: movie._id });

    for (const rev of reviewsToDel) {
        await Review.findByIdAndDelete(rev._id);
    }


    // console.log("movie deleted from references")
}

const getTrendingGenres = async (req, res) => {
    try {
        const genreTrends = await Movie.aggregate([
            { $unwind: "$genre" },
            { $group: { _id: "$genre", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 5 }
        ]);

        res.status(200).json(genreTrends);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


module.exports = {
    createMovie,
    getMoviesByFilter,
    getTopMoviesByGenre,
    getTopMoviesOfTheMonth,
    getMovies,
    getMovieById,
    updateMovie,
    deleteMovie,
    getMoviesByFilter,
    getMostPopularMovies,
    getTrendingGenres
};